"""Run preflight, smoke, training, generation and export inside one 9000 s budget."""
import argparse
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import re
import signal
import sys
import time
import zipfile

from budget import Budget, complete_generation_prefix, recover_checkpoint, run_bounded, tensor_count
from core import dump, read_jsonl


LIMIT = 9000
EXPORT_RESERVE = 180
INFERENCE_RESERVE = 30 * 60
VERSIONS = {
    'torch': '2.7.1+cu128', 'transformers': '4.51.3', 'peft': '0.15.2',
    'accelerate': '1.6.0', 'safetensors': '0.5.3', 'huggingface-hub': '0.30.2',
    'tokenizers': '0.21.1',
}


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def verify(root):
    manifest = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    for rel, expected in manifest['files_sha256'].items():
        path = (root/rel).resolve()
        if not path.is_relative_to(root) or sha(path) != expected:
            raise ValueError('Worker package checksum mismatch: '+rel)
    for name in ('val.jsonl', 'case_metrics.py', 'baseline_pred.jsonl', 'dev_targets.jsonl'):
        if (root/'data'/name).exists():
            raise ValueError('Separate evaluation input found in training directory: '+name)


def export_result(out, export):
    files = sorted(p for p in out.rglob('*') if p.is_file()
                   and (p.parent == out or p.parent == out/'fit'/'adapter'
                        or (p.parent in (out/'fit', out/'smoke', out/'preflight') and p.name in {
                            'training_complete.json', 'trainer_state.json', 'tokenization.json',
                            'identity.json', 'parameter_audit.json',
                        }))
                   and p.name != 'RESULT_MANIFEST.json')
    manifest = {p.relative_to(out).as_posix(): sha(p) for p in files}
    dump(out/'RESULT_MANIFEST.json', {'files_sha256': manifest})
    temporary = export.with_suffix('.part')
    # STORE makes export time predictable and avoids compressing weights twice.
    with zipfile.ZipFile(temporary, 'x', zipfile.ZIP_STORED) as z:
        for p in [*files, out/'RESULT_MANIFEST.json']:
            z.write(p, p.relative_to(out).as_posix())
    with zipfile.ZipFile(temporary) as z:
        corrupt = z.testzip()
        if corrupt:
            raise ValueError('Result archive CRC failed: '+corrupt)
    temporary.rename(export)


def run_trial(root, run_name, mode, budget):
    verify(root)
    config = json.loads((root/'trial_config.json').read_text(encoding='utf-8'))
    if config['total_budget_seconds'] != budget.limit:
        raise ValueError('Invalid experiment time budget')
    versions = {name: metadata.version(name) for name in VERSIONS}
    if versions != VERSIONS or sys.version_info[:2] != (3, 12):
        raise ValueError(f'Use the notebook Python 3.12 environment with pinned dependencies: {versions}')
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'
    os.environ.setdefault('CUDA_VISIBLE_DEVICES', '0')
    out = root/'runs'/run_name
    out.mkdir(parents=True, exist_ok=False)
    export = root/f"{config['trial_id']}_{run_name}_RESULT.zip"
    if export.exists():
        raise FileExistsError(export)
    commands, generation, errors = [], {}, []
    complete = None
    shared = json.loads((root/'SHARED_IDENTITY.json').read_text(encoding='utf-8'))
    model = {key: config[key] for key in ('model_id', 'revision')}
    dump(out/'runtime.json', {'python':sys.version, 'packages':versions, 'platform':platform.platform(),
                              'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'], 'utc_started':utc_now()})
    for name in ('trial_config.json', 'source_audit.json', 'MANIFEST.json'):
        (out/f'worker_{name}').write_bytes((root/name).read_bytes())

    def phase(label, script, args, seconds, grace):
        deadline = time.monotonic()+max(0, seconds-grace)
        cmd = [sys.executable, '-B', str(root/'code'/script), *map(str, args), '--deadline', str(deadline)]
        entry = {'phase':label, 'argv':cmd, 'started_utc':utc_now(), 'allocated_seconds':seconds}
        print(f'{label}: at most {seconds/60:.1f} minutes (total left {budget.remaining()/60:.1f})', flush=True)
        result = run_bounded(cmd, root, seconds, out/'run.log')
        entry.update(result, finished_utc=utc_now())
        commands.append(entry)
        dump(out/'commands.json', commands)
        if result['returncode'] != 0:
            errors.append({'phase':label, **result})
        return result

    status = 'complete'
    for label, minutes in [('preflight', 25), ('smoke', 10), ('train', 150)]:
        if mode == 'check' and label != 'preflight':
            break
        if mode == 'smoke' and label == 'train':
            break
        folder = out/('fit' if label == 'train' else label)
        seconds = budget.phase_seconds(minutes*60, INFERENCE_RESERVE+EXPORT_RESERVE)
        result = phase(label, 'train.py', ['--root',root,'--out',folder,'--phase',label], seconds, grace=120)
        if label == 'train':
            marker = folder/'training_complete.json'
            weights = folder/'adapter'/'adapter_model.safetensors'
            if marker.is_file() and weights.is_file():
                complete = json.loads(marker.read_text(encoding='utf-8'))
            elif result['timed_out']:
                complete = recover_checkpoint(folder, model, config)
            if complete:
                if (complete['phase'] != 'train' or complete['steps'] < 1
                    or complete['model'] != model or complete['config'] != config
                    or tensor_count(weights) != config['parameter_audit']['temporal_adapter']):
                    raise ValueError('Training completion identity or adapter parameter count mismatch')
                if not complete['completed_schedule'] or result['timed_out']:
                    status = 'partial_training'
                if result['returncode'] != 0 and not result['timed_out']:
                    status = 'failed_runtime'
                break
        if result['returncode'] != 0 or (label == 'train' and complete is None):
            status = 'budget_exhausted_no_checkpoint' if result['timed_out'] else 'failed_runtime'
            break

    if mode != 'train':
        if status != 'complete':
            raise RuntimeError(f'{mode} failed: {status}; see {out}/run.log')
        return

    if complete:
        adapter = out/'fit'/'adapter'
        adapter_hash = sha(adapter/'adapter_model.safetensors')
        for split in ('dev', 'public'):
            tasks_path = root/'data'/f'{split}_tasks.jsonl'
            raw_path = out/f'{split}_raw.jsonl'
            seconds = budget.remaining(EXPORT_RESERVE)
            if split == 'dev':
                seconds *= 0.49
            result = phase(split, 'generate.py', ['--tasks',tasks_path,'--adapter',adapter,
                           '--out',raw_path,'--max-length',config['max_length'],
                           '--max-new-tokens',config['max_new_tokens']], seconds, grace=15)
            reason = ('time_budget_exhausted' if result['timed_out'] or result['returncode'] == 0
                      else 'generation_runtime_error')
            generation[split] = complete_generation_prefix(read_jsonl(tasks_path), raw_path, reason)
            marker = raw_path.with_suffix('.identity.json')
            if not marker.exists():
                dump(marker, {'tasks_sha256':sha(tasks_path), 'base':model, 'adapter_sha256':adapter_hash,
                     'generation_config':{'do_sample':False,'num_beams':1,
                         'max_new_tokens':config['max_new_tokens'],'pad_token_id':151645,'eos_token_id':151645},
                     'not_started_or_interrupted_before_model_ready':True})
        if any(e['phase'] in generation and not e['timed_out'] for e in errors):
            status = 'failed_runtime'
        elif status == 'complete' and (any(g['budget_abstentions'] for g in generation.values())
                                         or any(e['phase'] in generation for e in errors)):
            status = 'partial_inference'

    dump(out/'result_identity.json', {
        'trial_id':config['trial_id'], 'config':config, 'shared':shared, 'model':model,
        'package_manifest_sha256':sha(root/'MANIFEST.json'), 'status':status, 'complete_utc':utc_now(),
        'official_val_gold_present':config['final_refit'], 'official_val_scored':False,
    })
    dump(out/'budget_report.json', {
        'limit_seconds':budget.limit, 'elapsed_before_export_seconds':budget.elapsed(),
        'trained_checkpoint_available':complete is not None, 'generation':generation,
        'errors':errors, 'status':status, 'dependency_install_and_cpu_scoring_included':False,
        'phase_wall_seconds':{c['phase']:c['wall_seconds'] for c in commands},
    })
    export_result(out, export)
    print('RESULT ZIP:', export, flush=True)
    print(f'{status}; total including export: {budget.elapsed():.2f}s', flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--run-name', required=True)
    ap.add_argument('--mode', choices=('check','smoke','train'), default='train')
    a = ap.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', a.run_name):
        ap.error('Use a short run name with letters, digits, dash or underscore')
    budget = Budget(LIMIT)

    def hard_stop(signum, frame):
        raise TimeoutError('150-minute total deadline reached; inspect the run directory for partial files')

    signal.signal(signal.SIGALRM, hard_stop)
    signal.setitimer(signal.ITIMER_REAL, budget.remaining())
    try:
        run_trial(a.root.resolve(), a.run_name, a.mode, budget)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    main()
