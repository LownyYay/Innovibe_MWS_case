"""Stdlib-only wall-clock budget and explicit abstention after a deadline."""
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import threading
import time


def parameter_counts(base, temporal_adapter, extractor_adapter):
    counts = {'base_unique_per_model':base, 'temporal_adapter':temporal_adapter,
              'extractor_adapter':extractor_adapter,
              'two_component_total':2*base + temporal_adapter + extractor_adapter,
              'limit':1_500_000_000}
    if counts['two_component_total'] > counts['limit']:
        raise ValueError('Pipeline exceeds 1.5 billion parameters')
    return counts


def tensor_count(path):
    """Read shape metadata, checking that the weight file was fully written."""
    with Path(path).open('rb') as f:
        size = int.from_bytes(f.read(8), 'little')
        if not 2 <= size <= 10_000_000:
            raise ValueError('Invalid safetensors header size')
        header = json.loads(f.read(size))
    tensors = [item for key,item in header.items() if key != '__metadata__']
    if not tensors or path.stat().st_size != 8 + size + max(t['data_offsets'][1] for t in tensors):
        raise ValueError('Incomplete safetensors file')
    return sum(math.prod(t['shape']) for t in tensors)


class Budget:
    def __init__(self, seconds, clock=time.monotonic):
        if seconds <= 0:
            raise ValueError('Positive time budget required')
        self.clock = clock
        self.started = clock()
        self.limit = float(seconds)

    def elapsed(self): return max(0.0, self.clock()-self.started)
    def remaining(self, reserve=0): return max(0.0, self.limit-self.elapsed()-reserve)

    def phase_seconds(self, maximum, reserve):
        return max(0.0, min(float(maximum), self.remaining(reserve)))


def run_bounded(command, cwd, timeout_seconds, output, printer=print):
    """Kill only this phase's process group at its allocated hard deadline."""
    if timeout_seconds <= 0:
        return {'returncode':None,'timed_out':True,'wall_seconds':0.0,'not_started':True}
    started=time.monotonic()
    timed_out=threading.Event()
    process=subprocess.Popen(command,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
        text=True,encoding='utf-8',errors='replace',bufsize=1,
        start_new_session=(os.name=='posix'))

    def stop():
        if process.poll() is not None:return
        timed_out.set()
        try:
            if os.name=='posix':os.killpg(process.pid,signal.SIGKILL)
            else:process.kill()
        except ProcessLookupError:pass

    timer=threading.Timer(timeout_seconds,stop)
    timer.daemon=True;timer.start()
    try:
        with Path(output).open('a',encoding='utf-8') as stream:
            for line in process.stdout:
                printer(line,end='',flush=True)
                stream.write(line);stream.flush()
        code=process.wait()
    except BaseException:
        stop()
        process.wait()
        raise
    finally:
        timer.cancel()
        process.stdout.close()
    return {'returncode':code,'timed_out':timed_out.is_set(),
            'wall_seconds':time.monotonic()-started,'not_started':False}


def prompt_hash(messages):
    return hashlib.sha256(json.dumps(messages,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def complete_generation_prefix(tasks,path,reason='time_budget_exhausted'):
    """Retain valid generated prefix; fill every remaining ID with a marked abstention."""
    path=Path(path);prefix=[];dropped_partial_tail=False
    if path.exists():
        raw=path.read_bytes()
        try:text=raw.decode('utf-8')
        except UnicodeDecodeError as exc:
            if exc.end!=len(raw) or exc.reason!='unexpected end of data':raise
            end=raw.rfind(b'\n')
            text=raw[:end+1].decode('utf-8')
            dropped_partial_tail=True
        lines=text.splitlines()
        for n,line in enumerate(lines):
            if not line.strip():continue
            try:record=json.loads(line)
            except json.JSONDecodeError:
                if n != len(lines)-1:raise ValueError('Corrupt generation before final partial line')
                dropped_partial_tail=True;break
            if len(prefix)>=len(tasks) or record['call_id']!=tasks[len(prefix)]['call_id']:
                raise ValueError('Generation is not an ordered task prefix')
            if record['prompt_sha256']!=prompt_hash(tasks[len(prefix)]['messages']):
                raise ValueError('Generated prompt hash mismatch')
            prefix.append(record)
    generated_prefix=len(prefix)
    for task in tasks[len(prefix):]:
        prefix.append({'call_id':task['call_id'],'text':'','prompt_sha256':prompt_hash(task['messages']),
                       'input_tokens':0,'output_tokens':0,'hit_token_limit':False,
                       'error':reason,'time_budget_exhausted':reason=='time_budget_exhausted'})
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in prefix),encoding='utf-8')
    temporary.replace(path)
    abstained=sum(bool(r.get('time_budget_exhausted')) for r in prefix)
    runtime_errors=sum(bool(r.get('error')) and not r.get('time_budget_exhausted') for r in prefix)
    return {'calls':len(tasks),'retained_prefix_rows':generated_prefix,
            'actually_generated_calls':len(tasks)-abstained-runtime_errors,'budget_abstentions':abstained,
            'runtime_error_abstentions':runtime_errors,
            'dropped_partial_tail':dropped_partial_tail}


def recover_checkpoint(fit,model_identity,config):
    """Promote a persisted adapter after a hard stop; never invent trained weights."""
    import shutil
    fit=Path(fit)
    choices=[]
    for p in fit.glob('checkpoint-*'):
        try:
            state=json.loads((p/'trainer_state.json').read_text(encoding='utf-8'))
            adapter_config=json.loads((p/'adapter_config.json').read_text(encoding='utf-8'))
            if (state['global_step'] > 0 and p.name == f"checkpoint-{state['global_step']}"
                and adapter_config['r'] == config['lora_r']
                and tensor_count(p/'adapter_model.safetensors') == config['parameter_audit']['temporal_adapter']):
                choices.append((state['global_step'],p,state))
        except (OSError, ValueError, KeyError):
            # A hard stop can interrupt writes. Try the other persisted epoch checkpoint.
            continue
    if not choices:return None
    latest_step,chosen,state=max(choices,key=lambda x:x[0])
    planned_steps=state['max_steps']
    preferred=state.get('best_model_checkpoint')
    if preferred:
        name=Path(preferred).name
        match=next((v for v in choices if v[1].name==name),None)
        if match is not None:_,chosen,state=match
    adapter=fit/'adapter';adapter.mkdir(exist_ok=True)
    for p in chosen.iterdir():
        if p.is_file() and (p.name.startswith('adapter_') or p.name=='README.md'):
            shutil.copy2(p,adapter/p.name)
    for p in (fit/'tokenizer').iterdir():
        if p.is_file():shutil.copy2(p,adapter/p.name)
    (adapter/'base_identity.json').write_text(json.dumps(model_identity,indent=2)+'\n',encoding='utf-8')
    complete={'phase':'train','steps':latest_step,'config':config,'model':model_identity,
              'best_checkpoint':str(chosen),'best_dev_loss':state.get('best_metric'),
              'selected_checkpoint_step':state['global_step'],'planned_steps':planned_steps,
              'completed_schedule':False,'budget_stopped':True,
              'recovery':'persisted checkpoint promoted after phase timeout'}
    (fit/'training_complete.json').write_text(json.dumps(complete,indent=2)+'\n',encoding='utf-8')
    shutil.copy2(chosen/'trainer_state.json',fit/'trainer_state.json')
    return complete
