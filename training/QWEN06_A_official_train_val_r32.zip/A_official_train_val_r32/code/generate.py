"""Greedy date proposals from prepared messages; never opens gold/scorer/catalog."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
from peft import PeftModel
from huggingface_hub import snapshot_download
from core import dump, read_jsonl


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for key in ('tasks','adapter','out'):
        ap.add_argument('--'+key, type=Path, required=True)
    ap.add_argument('--max-length', type=int, required=True)
    ap.add_argument('--max-new-tokens', type=int, required=True)
    ap.add_argument('--deadline', type=float, required=True, help='Stop between calls on the monotonic clock')
    a = ap.parse_args()
    # Refuse accidentally using a smoke adapter as the candidate model.
    complete = json.loads((a.adapter.parent/'training_complete.json').read_text(encoding='utf-8'))
    if complete['phase'] != 'train':
        raise ValueError('Generation requires completed full training, not smoke')
    identity = json.loads((a.adapter/'base_identity.json').read_text(encoding='utf-8'))
    base = snapshot_download(identity['model_id'], revision=identity['revision'], local_files_only=True)
    tok = AutoTokenizer.from_pretrained(a.adapter, local_files_only=True)
    tok.pad_token = tok.eos_token
    if tok.eos_token_id != 151645:
        raise ValueError('Unexpected inference EOS token')
    model = AutoModelForCausalLM.from_pretrained(base, local_files_only=True,
                torch_dtype=torch.bfloat16, attn_implementation='sdpa')
    model = PeftModel.from_pretrained(model, a.adapter).to('cuda').eval()
    model.config.use_cache = True
    gen = GenerationConfig(do_sample=False, num_beams=1, max_new_tokens=a.max_new_tokens,
             eos_token_id=tok.eos_token_id, pad_token_id=tok.pad_token_id,
             bos_token_id=tok.bos_token_id, use_cache=True)
    # Fresh config, not model's saved temperature/top_p defaults.
    if gen.do_sample is not False:
        raise AssertionError('Greedy contract')
    tasks = read_jsonl(a.tasks)
    if any(set(row) != {'call_id','messages'} for row in tasks):
        raise ValueError('Inference task records must contain only call_id/messages, no target/labels')
    provenance = {'tasks_sha256':hashlib.sha256(a.tasks.read_bytes()).hexdigest(),
                  'base':identity,'generation_config':gen.to_dict(),
                  'adapter_sha256':hashlib.sha256((a.adapter/'adapter_model.safetensors').read_bytes()).hexdigest()}
    marker = a.out.with_suffix('.identity.json')
    done = {}
    if a.out.exists():
        if not marker.exists() or json.loads(marker.read_text(encoding='utf-8')) != provenance:
            raise ValueError('Generation resume identity mismatch')
        done = {r['call_id']:r for r in read_jsonl(a.out)}
        expected = [r['call_id'] for r in tasks]
        if list(done) != expected[:len(done)]:
            raise ValueError('Existing output is not an exact task prefix')
    else:
        a.out.parent.mkdir(parents=True, exist_ok=True)
        dump(marker, provenance)
    wall, began = time.perf_counter(), datetime.now(timezone.utc).isoformat()
    generated_calls = 0
    with a.out.open('a', encoding='utf-8') as stream:
        for n, row in enumerate(tasks, 1):
            if row['call_id'] in done:
                continue
            if time.monotonic() >= a.deadline:
                break
            ids = tok.apply_chat_template(row['messages'], tokenize=True,
                      add_generation_prompt=True, enable_thinking=False)
            if len(ids)+a.max_new_tokens > a.max_length:
                raise ValueError('No truncation: prompt plus reserve too long')
            tensor = torch.tensor([ids], dtype=torch.long, device='cuda')
            with torch.inference_mode():
                output = model.generate(input_ids=tensor, attention_mask=torch.ones_like(tensor),
                                        generation_config=gen)
            generated = output[0, len(ids):].tolist()
            text = tok.decode(generated, skip_special_tokens=True)
            record = {'call_id':row['call_id'], 'text':text,
                      'prompt_sha256':hashlib.sha256(json.dumps(row['messages'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest(),
                      'input_tokens':len(ids), 'output_tokens':len(generated),
                      'hit_token_limit':len(generated)>=a.max_new_tokens}
            stream.write(json.dumps(record, ensure_ascii=False)+'\n')
            stream.flush()
            generated_calls += 1
            if n%20 == 0 or n==len(tasks):
                print(f'Generated {n}/{len(tasks)}; wall {time.perf_counter()-wall:.1f}s', flush=True)
    torch.cuda.synchronize()
    dump(a.out.with_suffix('.timing.json'), {'started_utc':began,
         'finished_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-wall,
         'calls':len(tasks),'generated_calls':generated_calls,'resumed_calls':len(done),'provenance':provenance})


if __name__ == '__main__': main()
