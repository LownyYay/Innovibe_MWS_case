"""Fit one Qwen3-0.6B LoRA under the worker deadline."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import torch
from torch.nn.functional import cross_entropy
from torch.utils.checkpoint import checkpoint
from torch.utils.data import Dataset
from transformers import AutoTokenizer, Qwen3ForCausalLM, Trainer, TrainerCallback, TrainingArguments, set_seed
from transformers.modeling_outputs import CausalLMOutputWithPast
from peft import LoraConfig, get_peft_model
from core import dump, read_jsonl
from model_io import encode, snapshot
from budget import parameter_counts


class TimeStop(TrainerCallback):
    def __init__(self, deadline):
        self.deadline = deadline
        self.stopped = False
        self.planned_steps = None

    def on_train_begin(self, args, state, control, **kwargs):
        self.planned_steps = state.max_steps

    def on_step_end(self, args, state, control, **kwargs):
        if time.monotonic() >= self.deadline and state.global_step < state.max_steps:
            self.stopped = True
            control.should_training_stop = True
            control.should_save = True
            control.should_evaluate = False
        return control

    def on_epoch_end(self, args, state, control, **kwargs):
        if self.stopped:
            # The partial checkpoint was saved at on_step_end. Skip the default
            # epoch evaluation and second save while exiting on a deadline.
            control.should_evaluate = False
            control.should_save = False
        return control


class Qwen3ForSFT(Qwen3ForCausalLM):
    def forward(self, input_ids=None, attention_mask=None, labels=None, num_items_in_batch=None, **kwargs):
        if labels is None:
            return super().forward(input_ids=input_ids, attention_mask=attention_mask, **kwargs)
        hidden = self.model(input_ids=input_ids, attention_mask=attention_mask,
                            use_cache=False, return_dict=True).last_hidden_state
        shifted = labels[:, 1:]
        mask = shifted.ne(-100)
        selected, targets = hidden[:, :-1][mask], shifted[mask]
        if targets.numel() == 0:
            raise ValueError('No supervised tokens')
        loss = hidden.new_zeros((), dtype=torch.float32)
        for start in range(0, targets.numel(), 128):
            h, y = selected[start:start+128], targets[start:start+128]
            loss = loss + (checkpoint(self.chunk_loss, h, y, use_reentrant=False)
                           if torch.is_grad_enabled() else self.chunk_loss(h, y))
        return CausalLMOutputWithPast(loss=loss / (targets.numel() if num_items_in_batch is None else num_items_in_batch))

    def chunk_loss(self, hidden, labels):
        return cross_entropy(self.lm_head(hidden).float(), labels, reduction='sum')


class Encoded(Dataset):
    def __init__(self, path, tokenizer, limit):
        self.items = [encode(tokenizer, row) for row in read_jsonl(path)]
        lengths = [len(x['input_ids']) for x in self.items]
        self.stats = {'n':len(lengths), 'max_tokens':max(lengths), 'mean_tokens':sum(lengths)/len(lengths)}
        if max(lengths) > limit:
            raise ValueError(f'No truncation: max sequence {max(lengths)} > max_length {limit}. Increase max_length before training, record the configuration change.')

    def __len__(self): return len(self.items)
    def __getitem__(self, i): return self.items[i]


class Collate:
    def __init__(self, pad): self.pad = pad
    def __call__(self, batch):
        n = max(len(x['input_ids']) for x in batch)
        return {'input_ids':torch.tensor([x['input_ids']+[self.pad]*(n-len(x['input_ids'])) for x in batch]),
                'attention_mask':torch.tensor([[1]*len(x['input_ids'])+[0]*(n-len(x['input_ids'])) for x in batch]),
                'labels':torch.tensor([x['labels']+[-100]*(n-len(x['labels'])) for x in batch])}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--phase', choices=['preflight','smoke','train'], required=True)
    ap.add_argument('--deadline', type=float, required=True, help='Soft stop on the host monotonic clock')
    a = ap.parse_args()
    root, out = a.root.resolve(), a.out.resolve()
    config = json.loads((root/'trial_config.json').read_text(encoding='utf-8'))
    model_path, identity = snapshot(out.parent, config)
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    tokenizer.pad_token = tokenizer.eos_token
    if tokenizer.eos_token_id != 151645:
        raise ValueError('Unexpected EOS token')
    tokenizer.padding_side = 'right'
    fit = Encoded(root/'data/fit.jsonl', tokenizer, config['max_length'])
    dev = Encoded(root/'data/dev.jsonl', tokenizer, config['max_length'])
    # Generation must also fit, including worst-case public inference input.
    prompt_stats = {}
    for split in ('dev', 'public'):
        longest = max(len(tokenizer.apply_chat_template(row['messages'], tokenize=True,
                      add_generation_prompt=True, enable_thinking=False))
                      for row in read_jsonl(root/'data'/f'{split}_tasks.jsonl'))
        if longest + config['max_new_tokens'] > config['max_length']:
            raise ValueError(f'{split} prompt + generation reserve exceeds max_length')
        prompt_stats[f'{split}_max_prompt_tokens'] = longest
    preflight = {'fit':fit.stats, 'dev':dev.stats, **prompt_stats,
                 'generation_reserve':config['max_new_tokens'], 'model':identity,
                 'dev_scope':config['evaluation_scope']['dev']}
    out.mkdir(parents=True, exist_ok=True)
    dump(out/'tokenization.json', preflight)
    if a.phase == 'preflight':
        print(json.dumps(preflight, indent=2), flush=True)
        return
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError('Exactly one visible CUDA GPU required per worker notebook')
    if torch.cuda.get_device_capability(0) != (12, 0) or '5090' not in torch.cuda.get_device_name(0):
        raise RuntimeError('This package targets one RTX 5090; use a matching server')
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError('BF16 required')
    run_identity = {'config':config, 'model':identity,
                    'fit_sha256':hashlib.sha256((root/'data/fit.jsonl').read_bytes()).hexdigest(),
                    'dev_sha256':hashlib.sha256((root/'data/dev.jsonl').read_bytes()).hexdigest(),
                    'phase':a.phase}
    if (out/'identity.json').exists():
        raise ValueError('Training output already used; choose a new RUN_NAME')
    dump(out/'identity.json', run_identity)
    if a.phase == 'smoke':
        # Longest fit and dev examples exercise peak activation memory before full training.
        fit.items = [max(fit.items, key=lambda x:len(x['input_ids']))]
        dev.items = [max(dev.items, key=lambda x:len(x['input_ids']))]
        probe = torch.randn((256,256), device='cuda', dtype=torch.bfloat16, requires_grad=True)
        (probe @ probe).float().mean().backward()
        torch.cuda.synchronize()
        del probe
        print(f'{torch.cuda.get_device_name(0)}; CUDA {torch.version.cuda}; BF16 backward passed', flush=True)
    set_seed(config['seed'])
    wall, began = time.perf_counter(), datetime.now(timezone.utc).isoformat()
    model = Qwen3ForSFT.from_pretrained(model_path, local_files_only=True,
                    torch_dtype=torch.bfloat16, attn_implementation='sdpa')
    if model.get_input_embeddings().weight is not model.get_output_embeddings().weight:
        raise ValueError('Qwen3 base input/output embeddings must be tied')
    base_count = sum(p.numel() for p in model.parameters())
    model.config.use_cache = False
    model = get_peft_model(model, LoraConfig(task_type='CAUSAL_LM', r=config['lora_r'],
                 lora_alpha=config['lora_alpha'], lora_dropout=config['lora_dropout'],
                 target_modules=['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']))
    model.peft_config['default'].base_model_name_or_path = identity['model_id']
    model.peft_config['default'].revision = identity['revision']
    model.enable_input_require_grads()
    model.print_trainable_parameters()
    measured = parameter_counts(base_count, sum(p.numel() for p in model.parameters()) - base_count,
                                config['parameter_audit']['extractor_adapter'])
    if measured != config['parameter_audit']:
        raise ValueError(f'Parameter audit differs from the pinned two-model count: {measured}')
    dump(out/'parameter_audit.json', measured)
    tokenizer.save_pretrained(out/'tokenizer')
    select_on_dev = a.phase == 'smoke' or not config['final_refit']
    args = TrainingArguments(output_dir=str(out), num_train_epochs=config['epochs'],
             max_steps=1 if a.phase=='smoke' else -1,
             per_device_train_batch_size=1, per_device_eval_batch_size=1,
             gradient_accumulation_steps=1 if a.phase=='smoke' else config['gradient_accumulation'],
             learning_rate=config['learning_rate'], lr_scheduler_type='cosine', warmup_ratio=0.05,
             bf16=True, bf16_full_eval=True, gradient_checkpointing=True,
             gradient_checkpointing_kwargs={'use_reentrant':False},
             eval_strategy='epoch' if select_on_dev else 'no', save_strategy='epoch', save_total_limit=2,
             load_best_model_at_end=select_on_dev, metric_for_best_model='eval_loss', greater_is_better=False,
             prediction_loss_only=True, logging_steps=1 if a.phase=='smoke' else 10,
             report_to='none', remove_unused_columns=False, dataloader_num_workers=0,
             optim='adamw_torch', seed=config['seed'], data_seed=config['seed'],
             save_safetensors=True)
    timer = TimeStop(a.deadline)
    trainer = Trainer(model=model, args=args, train_dataset=fit, eval_dataset=dev if select_on_dev else None,
                      data_collator=Collate(tokenizer.pad_token_id), callbacks=[timer])
    trainer.train()
    trainer.save_state()
    torch.cuda.synchronize()
    adapter = out/'adapter'
    trainer.save_model(str(adapter))
    tokenizer.save_pretrained(adapter)
    dump(adapter/'base_identity.json', identity)
    checkpoint = trainer.state.best_model_checkpoint
    pending = out/'training_complete.tmp'
    dump(pending, {'phase':a.phase, 'started_utc':began,
         'finished_utc':datetime.now(timezone.utc).isoformat(), 'wall_seconds':time.perf_counter()-wall,
         'peak_allocated_bytes':torch.cuda.max_memory_allocated(),
         'peak_reserved_bytes':torch.cuda.max_memory_reserved(),
         'best_checkpoint':checkpoint, 'best_dev_loss':trainer.state.best_metric,
         'selected_checkpoint_step':int(Path(checkpoint).name.rsplit('-', 1)[-1]) if checkpoint else trainer.state.global_step,
         'planned_steps':timer.planned_steps, 'budget_stopped':timer.stopped,
         'completed_schedule':trainer.state.global_step == timer.planned_steps,
         'steps':trainer.state.global_step, 'model':identity, 'config':config})
    pending.replace(out/'training_complete.json')


if __name__ == '__main__': main()
