"""Shared tokenizer contract for supervised fitting and greedy inference."""
import json
import hashlib
import re
from pathlib import Path
from core import dump


def encode(tokenizer, item):
    prefix = tokenizer.apply_chat_template(item['messages'], tokenize=True,
                    add_generation_prompt=True, enable_thinking=False)
    full = tokenizer.apply_chat_template(item['messages'] + [{'role': 'assistant', 'content': item['target']}],
                    tokenize=True, add_generation_prompt=False, enable_thinking=False)
    if full[:len(prefix)] != prefix:
        raise ValueError('Chat prefix mismatch: refusing wrong assistant loss mask')
    if tokenizer.eos_token_id not in full[len(prefix):]:
        raise ValueError('Target lacks EOS')
    return {'input_ids': full, 'labels': [-100] * len(prefix) + full[len(prefix):]}


def snapshot(root, config):
    from huggingface_hub import snapshot_download
    if not re.fullmatch(r'[0-9a-f]{40}',config['revision']):
        raise ValueError('Base revision must be a precommitted immutable SHA')
    identity_path = root / 'model_identity.json'
    if identity_path.exists():
        identity = json.loads(identity_path.read_text(encoding='utf-8'))
        if identity != {'model_id':config['model_id'],'revision':config['revision']}:
            raise ValueError('Model ID/revision differs from frozen identity')
    else:
        identity = {'model_id': config['model_id'], 'revision': config['revision']}
        dump(identity_path, identity)
    location = snapshot_download(identity['model_id'], revision=identity['revision'],
                    allow_patterns=['*.json', '*.safetensors', '*.model', '*.txt', '*.jinja'])
    for name,expected in config['tokenizer_files_sha256'].items():
        if hashlib.sha256((Path(location)/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('Pinned tokenizer checksum mismatch: '+name)
    return Path(location), identity
